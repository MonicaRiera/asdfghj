﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TouristAppV3.Model
{
    class CommentModel
    {
        private string _category;
        private string _name;
        private string _content;

        public String Category
        {
            get { return _category; }
            set { _category = value; }
        }

        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public String Content
        {
            get { return _content; }
            set { _content = value; }
        }

        public override string ToString()
        {
            return Content.ToString();
        }
    }
}
