﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Linq;
using Windows.Storage;
using TouristAppV3.Annotations;
using TouristAppV3.Common;
using TouristAppV3.Model;

namespace TouristAppV3.ViewModel
{
    class CommentViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Categories> _categoriesModels;
        private Categories _selectedCategory;
        private ObservableCollection<CategoryItemModel> _categoryItems;
        private CategoryItemModel _selectedCategoryItemModel;
        private CommentModel _newCommentModel;
        private ICommand _addNewComment;
        private ObservableCollection<CommentModel> _comments;

        public CommentViewModel()
        {
            
            _newCommentModel = new CommentModel();
            _addNewComment = new RelayCommand(AddNewCommentCommand);

            CategoriesModels = new ObservableCollection<Categories>();
            CategoryItems = new ObservableCollection<CategoryItemModel>();
            Comments = new ObservableCollection<CommentModel>();

            LoadCategories();
            LoadCategoryItemModels();
            LoadCommentModels();

        }

        private async void AddNewCommentCommand()
        {
            StorageFile file = null;
            try
            {
                file = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync("comments.xml");
            }
            catch (Exception)
            {
            }

            if (file == null)
            {
                StorageFolder installationFolder = Windows.ApplicationModel.Package.Current.InstalledLocation;
                string xmlfile = @"Assets\xml\Comments.xml";
                file = await installationFolder.GetFileAsync(xmlfile);
            }

            Stream LoadStream = await file.OpenStreamForReadAsync();
            XDocument commentDocument = XDocument.Load(LoadStream);
            LoadStream.Dispose();

            XElement commentList = commentDocument.Element("comments");

            XElement comment = new XElement("comment");
            comment.Add(new XElement("category", NewCommentModel.Category));
            comment.Add(new XElement("name", NewCommentModel.Name));
            comment.Add(new XElement("content", NewCommentModel.Content));

            commentList.LastNode.AddAfterSelf(comment);

            StorageFile saveFile = null;

            try
            {
                saveFile = await Windows.Storage.ApplicationData.Current.LocalFolder.CreateFileAsync("Comments.xml");
            }
            catch { }

            if (saveFile == null)
            {
                saveFile = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync("Comments.xml");
            }

            Stream saveStream = await saveFile.OpenStreamForWriteAsync();
            commentDocument.Save(saveStream);
            saveStream.Dispose();
        }

        private async void LoadCategories()
        {
            StorageFolder installationFolder = Windows.ApplicationModel.Package.Current.InstalledLocation;
            string xmlfile = @"Assets\xml\Categories.xml";
            StorageFile file = await installationFolder.GetFileAsync(xmlfile);

            Stream categoryStream = await file.OpenStreamForReadAsync();
            XDocument categoriesModelDocument = XDocument.Load(categoryStream);

            IEnumerable<XElement> categoriesModelsList = categoriesModelDocument.Descendants("category");

            CategoriesModels = new ObservableCollection<Categories>();

            foreach (XElement xElement in categoriesModelsList)
            {
                CategoriesModels.Add(new Categories()
                {
                    Name = xElement.Element("name").Value,
                    ImageUrl = xElement.Element("imageurl").Value,
                    CategoryItems = new List<CategoryItemModel>()
                });
            }
            OnPropertyChanged("CategoriesModels");
        }

        private async void LoadCategoryItemModels()
        {
            StorageFile file = null;
            try
            {
                file = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync("categoryitems.xml");
            }
            catch (Exception)
            {
            }

            if (file == null)
            {
                StorageFolder installationFolder = Windows.ApplicationModel.Package.Current.InstalledLocation;
                string xmlfile = @"Assets\xml\CategoryItems.xml";
                file = await installationFolder.GetFileAsync(xmlfile);
            }

            Stream categoryItemStream = await file.OpenStreamForReadAsync();
            XDocument categoryItemDocument = XDocument.Load(categoryItemStream);

            IEnumerable<XElement> categoryItemList = categoryItemDocument.Descendants("categoryitem");

            CategoryItems = new ObservableCollection<CategoryItemModel>();

            foreach (XElement xElement in categoryItemList)
            {
                CategoryItemModel ci = new CategoryItemModel();
                ci.Name = xElement.Element("name").Value;
                ci.Category = xElement.Element("category").Value;
                ci.Adress = xElement.Element("adress").Value;
                ci.Email = xElement.Element("email").Value;
                ci.ImageUrl = xElement.Element("imageurl").Value;
                ci.Phone = xElement.Element("phone").Value;
                ci.Web = xElement.Element("web").Value;

                CategoryItems.Add(new CategoryItemModel()
                {
                    CommentModels = new List<CommentModel>()
                });

                foreach (Categories categoriesModel in CategoriesModels)
                {
                    if (categoriesModel.Name.Equals(ci.Category))
                    {
                        categoriesModel.CategoryItems.Add(ci);
                    }
                }
            }
            OnPropertyChanged("CategoryItems");
        }

        private async void LoadCommentModels()
        {
            StorageFile file = null;
            try
            {
                file = await Windows.Storage.ApplicationData.Current.LocalFolder.GetFileAsync("comments.xml");
            }
            catch (Exception)
            {
            }

            if (file == null)
            {
                StorageFolder installationFolder = Windows.ApplicationModel.Package.Current.InstalledLocation;
                string xmlfile = @"Assets\xml\comments.xml";
                file = await installationFolder.GetFileAsync(xmlfile);
            }

            Stream commentStream = await file.OpenStreamForReadAsync();
            XDocument commentDocument = XDocument.Load(commentStream);

            IEnumerable<XElement> commentList = commentDocument.Descendants("comment");

            foreach (XElement xElement in commentList)
            {
                CommentModel com = new CommentModel();
                com.Category = xElement.Element("category").Value;
                com.Name = xElement.Element("name").Value;
                com.Content = xElement.Element("content").Value;

                //foreach (CategoryItemModel categoryItemModel in CategoryItems)
                //{
                //    if (categoryItemModel.Name.Equals(com.Name))
                //    {
                //        categoryItemModel.CommentModels.Add(com);
                //    }
                //}
            }
            OnPropertyChanged("Comments");
        }

        public ObservableCollection<Categories> CategoriesModels
        {
            get { return _categoriesModels; }
            set { _categoriesModels = value; }
        }

        public ObservableCollection<CategoryItemModel> CategoryItems
        {
            get { return _categoryItems; }
            set { _categoryItems = value; }
        }

        public ObservableCollection<CommentModel> Comments
        {
            get { return _comments; }
            set { _comments = value; }
        }

        public CategoryItemModel SelectedCategoryItemModel
        {
            get { return _selectedCategoryItemModel; }
            set { _selectedCategoryItemModel = value; }
        }

        public CommentModel NewCommentModel
        {
            get { return _newCommentModel; }
            set { _newCommentModel = value; }
        }

        public ICommand AddNewComment
        {
            get { return _addNewComment; }
            set { _addNewComment = value; }
        }

        public Categories SelectedCategory
        {
            get { return _selectedCategory; }
            set { _selectedCategory = value; }
        }

        

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
